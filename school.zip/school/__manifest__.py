{
    'name' : 'Education Management',
    'version' : '1.1',
    'authors' : 'swarup shah',
    'summary' : 'Education management Management System',
    'description' : 'This is school management system software supported in "odoo 17".',
    'sequence': -1,
    'category' : 'Education',
    'depends' : ['base','sale_management','stock_delivery'],
    'data':[
        "security/ir.model.access.csv",
        "views/menu.xml",
        "views/school_view.xml",
        'views/student.xml',
        'views/student_marks.xml',
        'views/student_result.xml',
        'views/female_student.xml',
        "views/teach.xml",
        "views/subject.xml",
        "views/class_view.xml",
    ]
}