/* @odoo-module */

import {A} from './class_a'
// A.include({
//     methodA(){
//         console.log("new_method")
//     }
// });
// class B extends A {
//     // constructor(name){
//     //     this.name=name
//     // }
//     methodB() {
//         // super(name)
//         // name = "swarup"
//         console.log("Method B from class B");
//     }

//     methodA() {
//         // print(name)
//         console.log("Overridden Method A in class B");
//     }

//     method_proto(){
//       let a = {
//          b: 99
//       }
//      console.log(a)
//     }
// }


// let b = new B()

// b.method_proto()

// b.methodB()
// b.methodA()

