from odoo import fields, models,api

class SchoolStudent(models.Model):
    _name = "school.student"
    _description = "This is school Student model."
    _inherit = "school.person"


    class_id = fields.Many2one('school.class', string="Class Room", help="Select the class of the student")
    subject_ids = fields.Many2many('school.subject', string="Subjects", help="Select the subjects of the student")
    enrollment_date = fields.Date(string="Enrollment Date", help="Enter the enrollment date of the student")
    school_id = fields.Many2one("school.profile", string="School", required=True, help="Select the school of the student")
    marks_ids = fields.One2many("student.mark", 'student_id', string="Student Marks")
    result_ids = fields.One2many("student.result","student_id",string="Results")


    
    @api.model
    def create(self, vals_list):
        # Check if vals_list contains a single record or multiple records
        if isinstance(vals_list, list):
            students = super(SchoolStudent, self).create(vals_list)
        else:
            students = super(SchoolStudent, self).create([vals_list])

        student_result_obj = self.env['student.result']
        student_marks_obj = self.env['student.mark']

        for student in students:
            # Create student result record
            student_result_obj.create({
                'student_id': student.id,
                'status': 'pending'
            })

            # Create student marks records for each newly created student
            for subject in student.subject_ids:
                student_marks_obj.create({
                    'student_id': student.id,
                    'subject_id': subject.id
                })

        return students

    
    def unlink(self):
        # Delete associated student result records using email and phone
        emails = self.mapped('email')
        phones = self.mapped('phone')
        student_results = self.env['student.result'].search([('student_id.email', 'in', emails), ('student_id.phone', 'in', phones)])
        student_marks = self.env['student.mark'].search([('student_id.email', 'in', emails), ('student_id.phone', 'in', phones)])
        student_results.unlink()
        student_marks.unlink()
        return super(SchoolStudent, self).unlink()