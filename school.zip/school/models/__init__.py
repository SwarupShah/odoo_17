from . import school
from . import  schoolPerson
from . import teach
from . import student
from . import student_result
from . import schoolClass
from . import subject
from . import student_marks
