from odoo import fields, models


class SchoolTeacher(models.Model):
    _name = "school.subject"
    _description = "This is school subject model."

    name = fields.Char(string="Subject Name", required=True, help="Enter the name of the subject")
    code = fields.Char(string="Code", help="Enter the code of the subject")
    teacher_ids = fields.Many2many('school.teacher', string="Teachers", required=True, help="Select the teachers for the subject")


