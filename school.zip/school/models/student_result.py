from odoo import fields, models, api,_
from odoo.exceptions import UserError


class StudentResult(models.Model):
    _name = "student.result"
    _description = "Student Result Model"

    student_id = fields.Many2one('school.student', string="Student", readonly=True)
    subject_id = fields.Many2one('school.subject', string="Subject", readonly=True)  # Add this field
    status = fields.Selection([
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ('failed', 'Failed')
    ], string="Status", default='pending', readonly=True)
    percentage = fields.Float(string="Percentage", help="Percentage of marks obtained", readonly=True)

    def unlink(self):
        raise UserError(_('You cannot delete the student result recurds.'))

    def copy(self, default=None):
        raise UserError(_('You cannot duplicate the student result recurds.'))