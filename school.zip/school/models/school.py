from odoo import fields, models,api,_
from odoo.exceptions import UserError


class SchoolProfile(models.Model):
    _name = "school.profile"
    _description = "This is school profile."

    def check_orm(self):
        pass

    name = fields.Char(string="School Name", required=True, help="Enter the name of the school")
    email = fields.Char(string="Email", help="Enter the email address of the school")
    phone = fields.Integer(string="Phone", help="Enter the phone number of the school")
    organisation = fields.Selection([("government", "Government"),("private", "Private")], string="Organisation", help="Select the type of organisation", default="private")
    student_ids = fields.One2many("school.student",'school_id', string="No. of student")
    teacher_ids = fields.One2many("school.teacher",'school_id', string="No. of teacher")
    class_ids = fields.One2many("school.class", "schools", string="Classes")

    
    def unlink(self):
        raise UserError(_('You cannot delete the school recurds.'))

    def copy(self, default=None):
        raise UserError(_('You cannot duplicate the school recurds.'))
    
class SaleOrder(models.Model):
    _inherit = "sale.order"

    checking_date = fields.Date(string = "Ordering Date", help="enter the date when order was placed")

    nick_name = fields.Char(string = "Nick Name")

    def action_cancel(self):
        # print(self.checking_date,self.date_order.date())
        if self.checking_date == self.date_order.date():
            raise UserError(_('You cannot cancal the order.'))

    # def copy(self, default=None):
    #     if self.checking_date == self.date_order.date():
    #         raise UserError(_('You cannot duplicate the order.'))

    

class addNickNick(models.Model):
    _inherit="stock.picking"
    
    nick_name = fields.Char(string = "Nick Name", readonly=True)

class writeDetail(models.Model):
    _inherit="sale.order.line"

    extra_tags = fields.Char(string = "Extra field", help="enter the date when order was placed")
